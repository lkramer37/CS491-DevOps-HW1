import linked_list


class Queue(linked_list):
    def __init__(self):
        self.queue = []
        super().__init__()
        pass

    def enqueue(self, data):
        # Adds items to end of list
        self.items.append(data, self.length)
        pass

    def dequeue(self):
        # Removes and returns item at the beginning of list
        return self.queue.remove(0)
        pass

    def size(self):
        return self.length()
