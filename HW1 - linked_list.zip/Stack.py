import linked_list


class Stack(linked_list):
    def __init__(self):
        self.stack = []
        super().__init__()

    def push(self, data):
        self.stack.insert(data, 0)

    def pop(self):
        return self.data.remove(0)

    def peek(self):
        return self.stack[0]

