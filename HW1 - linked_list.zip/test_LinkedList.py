import unittest
import linked_list


class TestLinkedList(unittest.TestCase):
    def setUp(self):
        self.node1 = linked_list.Node()
        self.node2 = linked_list.Node()
        self.node3 = linked_list.Node()
        self.list = linked_list.LinkedList()

    def test_list_node(self):
        self.assertEqual(self.list.data, None)
        self.assertEqual(self.list.next, None)

    def test_length(self):
        self.assertEqual(self.list.length(), 0)
        self.list.append('second')
        self.assertEqual(self.list.length(), 1)
        self.list.append('third')
        self.assertEqual(self.list.length(), 2)
        self.list.remove(1)
        self.assertEqual(self.list.length(), 1)

    def test_is_empty(self):
        self.assertTrue(self.list.is_empty())
        self.list.append(self.node1)
        self.assertFalse(self.list.is_empty())
        pass
    
    def test_append(self):
        self.node1.data = 'a'
        self.node2.data = 'b'
        self.node3.data = 'c'

        self.list.append(self.node1)
        self.list.print_list()
        self.assertEqual(self.list.data, 'a')

    def test_insert(self):
        # self.node1.data = 'a'
        # self.node1.next = self.node3
        # self.node3.data = 'c'




        pass

    def test_delete(self):
        pass


if __name__ == '__main__':
    unittest.main()
