import unittest


class TestStack(unittest.TestCase):
    def test_something(self):
        self.assertEqual(True, False)

    def test_empty(self):
        # Create an empty Stack. Test that its size is 0.
        pass

    # Push an element onto the stack. Test that its size is now 1.
    # Push another element onto the stack. Test that its size is now 2.
    # Pop an element from the stack. Test that it matches the 2nd pushed value.
    #   Check that the size of the stack is now 1.
    # Pop an element from the stack. Test that it matches the 1st pushed value.
    #   Check that the size of the stack is 0.
    # Attempt to pop an element from the stack.
    #   You should receive an ArrayIndexOutOfBounds exception.


if __name__ == '__main__':
    unittest.main()
